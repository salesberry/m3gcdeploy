<?php


function event_details()
{
    if (isset($_GET['id']) && $_GET['id'] != 0) {

        $id = $_GET['id'];
        require('app/connection.inc.php');

        $sql = "SELECT * FROM events INNER JOIN event_details ON event_details.event_id = events.id WHERE events.id = ?";

        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            echo "STMP FAILED";
            header("Location: index.php");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($resultData)) {
            return $row;
        } else {
            header("Location: index.php");
            exit();
        }

        mysqli_stmt_close($stmt);
    } else {
        header("Location: index.php");
        exit();
    }
}

$event_details = event_details();

require('includes/header.inc.php');


?>



<!-- Feature -->
<div class="about-area">
    <div class="container" style="padding-top: 100px;">
        <div class="section-title" style="z-index:-1;height:300px;background-image:url(assets/img/banner/cycling.webp); background-repeat:no-repeat; background-position: center; background-size: auto; background-size: cover;">

        </div>
        <div style="margin: -100px 20px 0px 20px;">
            <div style="width: 150px;height: 150px; overflow: hidden; z-index:1; border-radius:5px; margin-right:10px !important">
                <img style="object-fit:cover; height:100%; width:100%" src="https://dgalywyr863hv.cloudfront.net/pictures/clubs/196654/4628503/5/large.jpg">
            </div>
            <div class="club_details" style="padding-left: 0px;">
                <h4 style="margin-bottom: 5px;"><?php echo $event_details['overview']; ?></h4>
                <p style="margin-bottom: 0px;">Pune, Maharashtra 500053</p>
            </div>
        </div>
        <ul class="nav nav-tabs" style="margin: 20px 20px 0px 20px;">
            <li class="nav-item">
                <a class="nav-link active_details active club_address" aria-current="page" href="#">Overview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link club_address" href="#">Details</a>
            </li>
            <li class="nav-item">
                <a class="nav-link club_address" href="#">Leaderboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link club_address" href="#">Members</a>
            </li>
        </ul>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-lg-9 p-4">
                    <p style="margin-bottom:4px"><i class="icofont-tasks-alt" style="margin-right: 10px;"></i>Complete the Virtual TCS New York City Marathon...</p>
                    <p style="margin-bottom:4px"><i class="icofont-calendar" style="margin-right: 10px;"></i>Oct 23, 2021 to Nov 7, 2021</p>
                    <p style="margin-bottom:4px"><i class="icofont-medal" style="margin-right: 10px;"></i>Run 26.2M and earn a digital finisher badge.</p>
                    <div class="pb-3" style="margin-top:30px">
                        <h5 class="pb-3">Overview</h5>
                        <span style="color: #000000; margin-top:10px; display:block">Address</span>
                        <p>Falaknuma High School, Falaknuma, Near Engine Bowli, Hyderabad</p>
                        <span style="color: #000000; margin-top:10px; display:block">Short Desc</span>
                        <p>Make your own 26.2-mile course filled with TCS New York City Marathon magic. Whether you will be on the start line in Staten Island or celebrating with friends and family across the globe, take on the Virtual TCS New York City Marathon anywhere, anytime between October 23 and November 7. </p>
                        <span style="color: #000000; margin-top:10px; display:block">Vanity Url</span>
                        <a href="#" style="display:block; color:#007FB6">http://www.m3gc.com/wajahath_khan</a>
                        <span style="color: #000000; margin-top:10px; display:block">Contact No</span>
                        <a href="#" style="display:block; color:#007FB6">+919032632675</a>
                    </div>  


                    <?php

                    $event_type = 'sub_event';
                    $parent_id = $_GET['id'];

                    $sql = "SELECT * FROM events WHERE event_type = ? AND parent_event_id = ?";

                    $stmt = mysqli_stmt_init($conn);
                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        echo "STMP FAILED";
                        exit();
                    }
                    mysqli_stmt_bind_param($stmt, "si", $event_type, $parent_id);
                    mysqli_stmt_execute($stmt);

                    $resultData = mysqli_stmt_get_result($stmt);

                    if($row = mysqli_fetch_assoc($resultData)){

                    echo'                   
                    <div class="pb-3" style="border-top:1px solid #dfdfe8; margin-top:30px; padding-top: 30px;">
                        <h5>List of Events</h5>
                        <p class="pb-3">Based on the calculative figure of all participant</p>
                        <div class="row">';
                    }
                    while ($row = mysqli_fetch_assoc($resultData)) {
                        $start_date = date_create($row['start_date']);
                        $end_date = date_create($row['end_date']);
                        echo 
                        '<div class="col-sm-6 col-lg-4">
                            <div class="blog-item">
                                <div class="top">
                                    <a href="event_details.php?id='.$row['id'].'">
                                        <img src="assets/uploads/'.$row['cover_image'].'" alt="Blog">
                                    </a>
                                </div>
                                <div class="bottom">
                                    <h3>
                                        <a href="event_details.php?id='.$row['id'].'">'.$row['event_name'].'</a>
                                    </h3>
                                    <p>'.$row['event_short_desc'].'</p>
                                    <a class="blog-btn" href="blog-details.html">'.date_format($start_date,"d/m/Y").' to '.date_format($end_date,"d/m/Y").'</a>
                                </div>
                            </div>
                        </div>';
                    }
                    if($row = mysqli_fetch_assoc($resultData)){

                    echo'</div></div>';

                    }

                    mysqli_stmt_close($stmt);

                    ?>





                </div>
                <div class="col-sm-12 col-lg-3 pt-4">
                    <?php 

                    if($event_details['can_participate'] == 'yes'){
                        echo'
                    <div class="rules-item pb-5" style="border-bottom:1px solid #dfdfe8">
                        <h5>Event Stats</h5>
                        <p class="pb-3"> Based on the calculative figure of all participant</p>
                        <div>
                            <span style="color: #000000; margin-top:10px; display:block">Time / Week</span>
                            <p>'.$event_details['event_time'].'</p>
                            <span style="color: #000000; margin-top:10px; display:block">All time Distance</span>
                            <p>'.$event_details['event_distance'].'</p>
                        </div>
                        <h5>Event Participation</h5>
                        <span style="color: #000000; margin-top:20px !important; display:block">Participated</span>
                        <p>'.$event_details['participated'].'</p>
                        <a class="common-btn" style="border-radius:8px; padding:8px 12px " href="#">Participate Now</a>
                        <span style="color: #000000; margin-top:20px !important; display:block">Leader</span>
                        <a href="#" style="display:block; color:#007FB6">Wajahath Khan</a>
                        <p>Miles Cover: 23m</p>
                        <span style="color: #000000; margin-top:20px !important; display:block">Top 5 on Leaderboard</span>

                        <a href="#" style="display:block; color:#007FB6">Wajahath Khan</a>
                        <p>Miles Cover: 23m</p>
                        <a href="#" style="display:block; color:#007FB6">Wajahath Khan</a>
                        <p>Miles Cover: 23m</p>
                        <a href="#" style="display:block; color:#007FB6">Wajahath Khan</a>
                        <p>Miles Cover: 23m</p>
                        <a href="#" style="display:block; color:#007FB6">Wajahath Khan</a>
                        <p>Miles Cover: 23m</p>
                        <a href="#" style="display:block; color:#007FB6">Wajahath Khan</a>
                        <p>Miles Cover: 23m</p>
                    </div>
                    ';
                    }
                    ?>
                    <div class="rules-item pb-5 pt-5">
                        <h5>Social Connection</h5>
                        <a href="<?php echo $event_details['facebook']?>" target="_blank" style="margin-top:20px !important; display:block; color:#007FB6">Facebook</a>
                        <p>Connect with Facebook and Get Our Latest Updates directly on Facebook</p>
                        <a href="<?php echo $event_details['instagram']?>" target="_blank" style="margin-top:20px !important; display:block; color:#007FB6">Instagram</a> 
                        <a href="<?php echo $event_details['twitter']?>" target="_blank" style="margin-top:20px !important; display:block; color:#007FB6">Twitter</a>
                        <p>Connect with Twitter and Get Automatic Update and Stay Connected</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Feature -->




</div>
</div>
</section>
<!-- End Team -->

<?php

require('includes/footer.inc.php');

?>