<?php


$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "m3gcindia";
$baseUrl='http://localhost/m3gcindia/';

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName );


// $dbServername = "localhost";
// $dbUsername = "mysal9dz_root";
// $dbPassword = "Gutsy@12book!";
// $dbName = "mysal9dz_m3gcindia";

// $baseUrl='https://mysalesberry.com/m3gcindia/';

// $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName );