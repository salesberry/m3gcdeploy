
                    <div class="col-lg-3">
                        <div class="rules-item pb-5" style="border-bottom:1px solid #dfdfe8">
                            <h5>My Account</h5>
                            <span style="color: #000000; margin-top:20px !important; display:block">Email</span>
                            <p>wajahathkhan@gmail.com</p>
                            <span style="color: #000000; margin-top:20px !important; display:block">Club</span>
                            <a href="#" style="display:block; color:#007FB6">Pune Pmr Club</a>
                            <span style="color: #000000; margin-top:20px !important; display:block">Membership Status</span>
                            <p>Free Account</p>
                            <a class="common-btn" style="border-radius:8px; padding:8px 12px " href="#">Subscribe now</a>
                        </div>
                        <div class="rules-item pb-5 pt-5">
                            <h5>Social Connection</h5>
                            <a href="#" style="margin-top:20px !important; display:block; color:#007FB6">Garmin</a>
                            <p>Connect with Garmin and Get Automatic Data</p>
                            <a href="#" style="margin-top:20px !important; display:block; color:#007FB6">Google Fit</a>
                            <p>Connect with Google Fit and Track your google data directly from one dashboard.</p>
                            <a href="#" style="margin-top:20px !important; display:block; color:#007FB6">Connect with MyFitnessPal</a>
                            <p>Connect with MyFitnessPal and Get Automatic Data</p>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Rules -->
<?php

require('includes/footer.inc.php');

?>